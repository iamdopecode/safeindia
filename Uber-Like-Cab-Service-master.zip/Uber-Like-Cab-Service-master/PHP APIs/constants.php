<?php
	$dbServer='localhost';
	$dbUsername='root';
	$dbPassword='';
	$dbName='spic';


	// $dbServer='localhost';
	// $dbUsername='id2200402_anup';
	// $dbPassword='biappanwar';
	// $dbName='id2200402_near_cabs';
?>